function formatUser(
    name: string,
    age: number
): string {
    // 'Nauel Gómez' -> ['Nauel', 'Gómez'];
    // Nos ahorramos verificar que es un string para ejecutar split
    const hasSurname = name.split(' ').length > 1;
    return `Name: ${name}, age: ${age}`;
};

// Parámetros opcionales y con valores por defecto.
function formatUserOptionalParam(
    name: string = 'Default name',
    age?: number,
    // isMuggle: boolean, Los parámetros obligatorios siempre deberian ir al principio.
): string {
    let ret: string;
    ret = `Name: ${name}`;
    if (age) {
        ret += `, age: ${age}`;
    };
    return ret;
};

console.log(formatUserOptionalParam('Nauel Gómez', 34));
console.log(formatUserOptionalParam('Nauel Gómez'));
console.log(formatUserOptionalParam());
console.log(formatUserOptionalParam(undefined, 10));

// Función void
function printUser(
    name: string = 'Default name',
    age?: number,
): void { // no devuelve nada
    console.log(formatUserOptionalParam(name, age));
}


// Nos verifica la implementación:
// formatUser('Nauel Gomez', '34');
// formatUser(undefined, 34);


// Variables de tipos primitivos
let fullName: string = "Harry Potter";
let age: number = 11;
let isMuggle: boolean = true;

fullName = 10;
age = 'Once';

let tel: string | number = '+43600000000';
tel = 600000000;

// Tipos indefinidos
const request: any = {}; // No es recomendable
// Existen configs de eslint y tsconfig para rechazarlos.
const response: unknown = {};

// Inferencia de tipos
// Si no definimos el tipo, TS asume que el tipo es el de la inicialización
let howardsHouse = 'Griffindor';

console.log(fullName);



# 🧠 CHARSET: INTRODUCCIÓN A SASS  
**Curso: Frontend Pro – Material Complementario**

---

## 📘 1. ¿QUÉ ES SASS?

- 💡 Preprocesador CSS que permite escribir código más potente y organizado.
- 🎯 Se compila a CSS estándar.
- 🧰 Añade funcionalidades como:
  - Variables
  - Anidamiento
  - Mixins
  - Funciones
  - Herencia
  - Módulos (`@use`, `@forward`)
- 📝 Dos sintaxis disponibles:
  - `.scss`: estilo CSS (la más común)
  - `.sass`: indentado, sin llaves ni punto y coma

---

## ⚙️ 2. INSTALACIÓN Y USO BÁSICO

- 📦 Requiere Node.js (o usarlo vía herramientas como Parceljs, Vite, Webpack, etc.)
- En Parcel.js se puede importar directamente
- También podemos utilizarlo con su libreria de NPM:
  - ⬇️ Instalar CLI de Sass:
    ```bash
    npm install -g sass
    ```
  - ▶️ Compilar archivo `.scss` a `.css`:
    ```bash
    sass estilos.scss estilos.css
    ```

---

## 🧩 3. CONCEPTOS CLAVE DE SASS

### 🔹 VARIABLES

Guarda valores reutilizables (colores, fuentes, tamaños...):

```scss
$color-principal: #007bff;
$font-size-base: 16px;

body {
  color: $color-principal;
  font-size: $font-size-base;
}
```

---

### 🔹 ANIDAMIENTO

Anida selectores como en HTML. Mejora la legibilidad (usado con moderación):

```scss
nav {
  ul {
    list-style: none;
  }

  a {
    text-decoration: none;
    color: inherit;
  }
}
```

---

### 🔹 MIXINS

Bloques reutilizables de estilos. Pueden tener parámetros y contenido.

```scss
@mixin flex-center {
  display: flex;
  justify-content: center;
  align-items: center;
}

.caja {
  @include flex-center;
}
```

#### 📱 Ejemplo de media query reusable con `@content`:

```scss
@mixin responsive($breakpoint) {
  @if $breakpoint == mobile {
    @media (max-width: 576px) { @content; }
  } @else if $breakpoint == tablet {
    @media (max-width: 768px) { @content; }
  } @else if $breakpoint == desktop {
    @media (min-width: 1024px) { @content; }
  }
}

.header {
  font-size: 2rem;

  @include responsive(mobile) {
    font-size: 1.5rem;
  }
}
```

> ✅ Los mixins con `@content` permiten incluir bloques de código dinámico. Muy útil para media queries, grids, etc.

---

### 🔹 FUNCIONES (BÁSICO)

Calculan y devuelven un valor:

```scss
@function pxToRem($px) {
  @return $px / 16 * 1rem;
}

p {
  font-size: pxToRem(24);
}
```

---

### 🔹 EXTEND / HERENCIA

Permite reutilizar selectores existentes:

```scss
.boton {
  padding: 12px;
  border-radius: 8px;
  font-weight: bold;
}

.boton-secundario {
  @extend .boton;
  background-color: lightgray;
}
```

---

## 📦 4. ORGANIZACIÓN MODULAR (MODERN SASS)

### ⚠️ `@import` está obsoleto

Evita usarlo. Reemplázalo por `@use` y `@forward`.

---

### ✅ `@use`

Importa un archivo encapsulando sus variables y mixins:

```scss
// _variables.scss
$color-principal: #e91e63;

// estilos.scss
@use 'variables';

h1 {
  color: variables.$color-principal;
}
```

➡️ También puedes renombrar el módulo:
```scss
@use 'variables' as v;
color: v.$color-principal;
```

---

### 🔁 `@forward`

Reexporta módulos desde un archivo central:

```scss
// _colors.scss
$accent: #ff6600;

// _index.scss
@forward 'colors';

// main.scss
@use 'index';
h2 { color: index.$accent; }
```

---

## 🧪 5. PRÁCTICA GUIADA

Crea los siguientes archivos SCSS:

### `_variables.scss`  
```scss
$color-primario: #2ecc71;
$fuente-base: 'Inter', sans-serif;
$tamaño-texto: 18px;
```

### `_mixins.scss`  
```scss
@mixin centrado-flex {
  display: flex;
  justify-content: center;
  align-items: center;
}

@mixin responsive($breakpoint) {
  @if $breakpoint == mobile {
    @media (max-width: 576px) { @content; }
  }
}
```

### `main.scss`  
```scss
@use 'variables';
@use 'mixins';

body {
  font-family: variables.$fuente-base;
  font-size: variables.$tamaño-texto;
  background-color: variables.$color-primario;
}

.hero {
  @include mixins.centrado-flex;

  @include mixins.responsive(mobile) {
    flex-direction: column;
  }
}
```

Compila con:
```bash
sass main.scss main.css
```

---

## ✅ 6. BUENAS PRÁCTICAS

- ❌ No anidar más de 3 niveles.
- ✅ Usa `@use`/`@forward` para mantener el código limpio.
- 📂 Agrupa por funcionalidad: `base/`, `components/`, `layout/`, etc.
- 🔐 Prefija tus variables y mixins (`$btn-color`, `@mixin grid-col`...) para evitar conflictos.
